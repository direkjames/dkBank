# dkBank — store page (Markdown version)

**Title:** dkBank — Premium Bank with Online & Offline Interest, Tiers and Menus
**Tagline:** A real bank for your economy: interest while playing and while away, upgradeable tiers,
beautiful menus. 1.21.4 – 26.3.

---

## 🏦 A bank your players will actually use

dkBank gives every player a bank account next to their wallet. Money in the bank earns interest — a
little for every hour played, and a little for every day away — so players have a reason to save,
log in, and come back.

## ✨ Features

**Interest that can't be farmed**
- Online interest per hour played, offline interest for time away (compounding), separate rates
- AFK players earn the offline rate — AFK pools earn no more than logging off
- Interest on the lowest balance since the last payout: no deposit-collect-withdraw tricks
- Caps per tier keep growth linear, so your economy doesn't explode
- Alt-account limit: only the first accounts per connection can use the bank

**Bank tiers**
- Basic → Silver → Gold → Platinum → Diamond out of the box, fully configurable
- Each tier: its own interest rates, interest cap and maximum balance
- Upgrades are paid from the bank: a money sink that players want
- Tiers from ranks (`dkbank.tier.<name>`) for donor perks

**Premium menus**
- Main menu with balance, tier, interest and a live payout countdown
- Deposit/withdraw presets, type any amount, send money to online players' heads
- Tiers, upgrade confirmation, history, leaderboard podium
- The balance counts up and down after every change
- Every menu editable, custom heads from minecraft-heads.com

**For server owners**
- 24 PlaceholderAPI placeholders (scoreboard/TAB safe)
- `/bank top` leaderboard, economy report with an inflation watch
- SQLite or MySQL/MariaDB, shared across a network
- Every change is one database transaction — crash-tested, never loses a cent
- New settings added automatically on update; mistakes are reported, never overwritten
- Developer API with events

## 📋 Requirements
- Paper or Purpur 1.21.4 – 26.3, Java 21+
- Vault (or VaultUnlocked) and an economy plugin (EssentialsX, CMI, …)
- Optional: PlaceholderAPI

## 📖 Documentation
<link to your docs>

## 💬 Support
<link to your Discord>. Please include the output of `/bank admin info`.

## 📜 Terms
- One license per network/server owner. No redistribution, reselling or decompiling.
- No refunds after download (store policy permitting).
