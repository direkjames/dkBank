# Releasing a version

## Before the first sale

- [ ] Finish the real-server checklist in [TESTING.md](../TESTING.md) and run dkBank on your own server
      for a week or two.
- [ ] Create the support Discord (channels: #announcements, #support, #bug-reports, #suggestions).
- [ ] Publish the docs: the `docs/` folder works as-is on GitBook, a GitHub wiki or a public repo.
- [ ] Take the screenshots and GIFs below.
- [ ] Register dkBank on [bstats.org](https://bstats.org) (Bukkit platform) and put the id in
      `BSTATS_ID` in `plugin/src/main/java/dev/direk/dkbank/hook/Metrics.java`. Add simple pie charts
      named `storage`, `tiers`, `alt_limit`, `menus` and `economy`.
- [ ] After uploading to SpigotMC, put the resource id in `SPIGOT_RESOURCE_ID` in
      `plugin/src/main/java/dev/direk/dkbank/util/UpdateChecker.java` (the update checker reads the
      newest version from there; it stays off while the id is 0).

## Screenshots and GIFs

1. The main menu (GIF: open it, wait for a payout, the balance counts up)
2. Deposit menu → click a preset (GIF, shows the animation and sound)
3. Tiers menu, then the upgrade confirmation
4. The "while you were away" message after logging in
5. History menu and the leaderboard podium
6. A scoreboard or TAB list using `%dkbank_balance%` and `%dkbank_next_payout%`
7. `/bank admin economy`

Use a clean resource pack-free client, GUI scale 3, and a builder-friendly background.

## Each release

1. Update `version` in `gradle.properties` and add the changes to `CHANGELOG.md`.
2. `./gradlew build` (all tests must pass) and test the jar on the newest and oldest supported version.
3. Commit, tag (`git tag v1.0.0`) and push.
4. Upload `plugin/build/libs/dkBank-<version>.jar` to BuiltByBit, SpigotMC and Voxel.Shop with the
   changelog. Upload `api/build/libs/dkBank-API-<version>.jar` too, for developers.
5. Post in #announcements.

## Store text

`description-bbcode.txt` (BuiltByBit, SpigotMC) and `description.md` (Voxel.Shop, docs). Replace the
docs and Discord links first.
