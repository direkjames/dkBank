# dkBank testing

What's been tested automatically, and what still needs a real server before dkBank is sold.

## Done automatically

| Test | Result |
|---|---|
| Unit and database tests (`gradlew test`) | 102 tests: money maths, interest, tiers, alt limit, leaderboard, reports, menus, API types |
| Crash test: the bank killed (`kill -9`) 25 times while 4 threads deposit, withdraw, transfer, pay interest and buy tiers | 25,242 history lines, every balance matches its history to the cent, money conserved, database intact every time |
| Load test: 10,000 accounts on SQLite | heartbeat for 200 players: ~7 ms (was ~370 ms before batching); leaderboard top 100: 1 ms; totals: 1 ms; economy report: 11 ms; history page: 0.5 ms; database 3 MB |
| Two code reviews (money and storage; server, menus and threads) | All findings fixed, see the 0.9.0 changes in ROADMAP.md |

## MySQL / MariaDB tests

`MySqlStoreTest` runs the same kind of checks against a real MySQL or MariaDB server (row locks under
200 opposite transfers, every feature, finishing a half-done upgrade). It's skipped unless you point
it at an empty database:

```powershell
# Windows PowerShell, in the dkBank folder
$env:DKBANK_TEST_MYSQL_URL = "jdbc:mysql://localhost:3306/dkbank_test"
$env:DKBANK_TEST_MYSQL_USER = "root"
$env:DKBANK_TEST_MYSQL_PASSWORD = "your password"
.\gradlew.bat :plugin:test --tests "*MySqlStoreTest*"
```

Each test makes its own tables and removes them afterwards.

## On a real server (please tick these off)

**Versions** — start each with `runPaper-…` / `runPurpur-…`, then `/bank`, a deposit, a withdrawal and
`/bank admin reload`:

- [ ] Paper 1.21.4 · [ ] Paper 1.21.11 · [ ] Paper 26.1 · [ ] Paper 26.3
- [ ] Purpur 1.21.4 · [ ] Purpur 1.21.11 · [ ] Purpur 26.1 · [ ] Purpur 26.3

**MySQL**

- [ ] `storage.type: mysql` starts and creates the tables
- [ ] Two servers on the same database (proxy): pay between them, switch servers while online, check
      interest isn't paid twice (`/bank history`)

**Exploits** (try to break it)

- [ ] Spam-click deposit/withdraw buttons and the upgrade confirm: only one happens per click
- [ ] Deposit, then log out straight away: the money is in the bank (or back in the wallet), never both or neither
- [ ] Type an amount in chat, then log out before pressing Enter: nothing happens
- [ ] Stop EssentialsX (or remove Vault) and try deposits: a clear message, nothing lost
- [ ] Shift-click, number keys, drag and double-click in every menu: no items taken
- [ ] `/reload confirm` or a plugin manager reload with a menu open: the menu closes, no items kept
- [ ] Put a tab in `config.yml` and restart: dkBank refuses to start and says why; the file isn't changed
- [ ] The same during `/bank admin reload`: "nothing was reloaded"
- [ ] A typo like `intrest:` in config.yml: a warning names it

**Performance**

- [ ] With players online for an hour: `/spark profiler start`, then `/spark profiler stop` — dkBank
      should be well under 1% of the tick
- [ ] Scoreboard or TAB showing `%dkbank_balance%` and `%dkbank_next_payout%`: no errors in the console

**Your own server** — run it for a week or two before selling. Watch `/bank admin economy` daily:
interest created should look sensible next to the money in banks.
