# dkBank Roadmap

A premium bank plugin for Paper and Purpur: a bank balance separate from the wallet, with separate
online and offline interest rates. Closed source, with a public Developer API.

Status legend: ☐ planned · ◐ in progress · ☑ done

---

## Decisions

| Topic | Decision | Why |
|---|---|---|
| Name | **dkBank** | Checked free on BuiltByBit, SpigotMC and Voxel.Shop |
| Servers | **Paper and Purpur** | Purpur is a Paper fork, so one build covers both. Folia later |
| Minecraft | **1.21.4 up to 26.3**, one jar | Covers most active servers |
| Java | Compiled for **Java 21** | 1.21.x servers run Java 21, 26.x servers run Java 25. Java 21 code runs on both |
| API we compile against | **paper-api 1.21.4** | The oldest supported version. Anything it has also exists on newer servers |
| Economy | **Vault API** | Works with Vault and VaultUnlocked, and with any economy plugin that supports them |
| Money | **BigDecimal**, never `double` | No rounding drift, e.g. 0.1 + 0.2 is exactly 0.3 |
| Storage | **SQLite** (default), **MySQL / MariaDB** (networks) | Through HikariCP, all queries off the main thread |
| Libraries | HikariCP **shaded and relocated** into the jar | Works on servers without internet access, and can't clash with other plugins |
| Packages | `dev.direk.dkbank` (plugin), `dev.direk.dkbank.api` (API) | |
| Null safety | JSpecify `@NullMarked` | Paper's own standard; the JetBrains annotations aren't available to plugins on 1.21.4 |
| Licenses | Proprietary (plugin), MIT (API) | Done |
| Interest | Online 1%/hour played (simple), offline 1%/day (compounding), on the lowest balance, capped per tier | Compounding offline matches daily payouts; the cap keeps growth linear |

---

## Phase 0 · Project setup — `0.0.x` ☑

- ☑ Gradle 9.8 multi-module project: `api` (MIT, published for developers) and `plugin` (proprietary)
- ☑ Java 21 toolchain, paper-api 1.21.4, Vault API, PlaceholderAPI (soft), versions in `gradle/libs.versions.toml`
- ☑ HikariCP shaded and relocated to `dev.direk.dkbank.libs.hikari`
- ☑ Test server tasks for Paper and Purpur **1.21.4, 1.21.11, 26.1 and 26.3**, each with the right Java
- ☑ JUnit 6, with a setup test guarding plugin.yml and the Java 21 class format
- ☑ GitHub Actions: build and test on every push, jar attached to each run
- ☑ API entry point `DkBankAPI.get()`, registered as a Bukkit service

## Phase 1 · Core banking — `0.1.0` ☑

- ☑ Accounts created automatically at login (on the login thread, never the main thread)
- ☑ Deposit (wallet → bank), withdraw (bank → wallet), transfer (bank → another player's bank, online or offline)
- ☑ Amounts: `1000`, `1,000`, `1.5k`, `2m`, `1b`, `1t`, `all`, `half`; typed amounts round down, fees round up
- ☑ Optional fees on withdrawals and transfers, minimum and maximum amounts, maximum balance
- ☑ All-or-nothing: if the bank step fails the wallet is refunded, and if the wallet refuses the bank is refunded
- ☑ Each operation is one database transaction with the account locked, so money can't be spent twice
  (tested with 400 parallel withdrawals and 300 parallel opposite transfers)
- ☑ One operation at a time per player; everything in progress finishes before the server stops
- ☑ Transaction log with clickable paged `/bank history`
- ☑ Commands with tab completion, granular permissions, admin give / take / set / balance / history / reload
- ☑ `config.yml` and `messages.yml` (MiniMessage) that fill in new settings automatically on update
- ☑ SQLite (WAL, crash-safe) and MySQL / MariaDB through HikariCP
- ☑ Test servers come with Vault and EssentialsX
- ☐ To verify in game: deposit, withdraw, pay, history, admin commands, restart mid-transaction

## Phase 2 · Interest engine — `0.2.0` ☑

The core feature. Interest is calculated from timestamps, so it's exact, restarts and crashes never
double-pay or skip a payout, and offline accounts cost nothing.

- ☑ **Online interest:** 1% per hour of active play (simple, prorated at logout), paid every hour played
- ☑ **Offline interest:** 1% per day away, compounding, paid at login with a "while you were away" message
- ☑ Separate rates and periods, payout messages and sound, `/bank interest` for rates and next payout
- ☑ AFK players earn the offline rate. Paper's built-in idle time plus placeholders from EssentialsX, CMI
  and DirekAntiAFK (through PlaceholderAPI)
- ☑ Anti-abuse:
  - interest is paid on the lowest balance since the last payout (deposits earn from the next payout)
  - offline time counts up to `offline.max-time` (7 days)
  - only the balance up to the interest cap earns (100,000 by default; per tier in Phase 3)
  - maximum interest per payout, and never past the maximum balance
  - progress saved every minute; crashes never double-pay, at most a minute is lost
- ☑ Unit tests, including a simulated year of interest proving the cap keeps growth linear
- ☑ Default rates: online 1% per hour played, offline 1% per day, capped

## Phase 3 · Bank tiers — `0.3.0` ☑

- ☑ Tiers in `tiers.yml`: name, icon, upgrade cost, online and offline rate, interest cap, max per payout,
  max balance. Defaults: Basic, Silver, Gold, Platinum, Diamond (all 1%, capped per tier), plus Black as
  a rank-only example
- ☑ Upgrades bought with in-game money from the bank balance (takes money out of the economy), one
  tier at a time, in one database transaction; buying twice at once only charges once
- ☑ Permission tiers (`dkbank.tier.<name>`, not given to ops) for ranks and donor perks; the higher tier
  wins. `buyable: false` tiers are rank-only
- ☑ Confirmation before paying (clickable, 30 seconds), `/bank tiers`, `/bank admin tier`
- ☑ Tier shown in `/bank`, `/bank interest` and the history
- ☑ `0.3.1`: lighter (light gray) tier messages, rates shown in `/bank tiers`, decimal rates (0.5%, 1.25%) documented and tested

## Phase 4 · GUIs — `0.4.0` ☑

- ☑ Main menu: balance, wallet, tier, rates, earning base, live next-payout countdown, quick actions
- ☑ Deposit and withdraw menus with preset amounts (configurable), half, all and a typed amount
- ☑ Typed amounts and names by chat prompt (hidden from chat, cancel word, timeout)
- ☑ Transfer menu (online players' heads, paged, or type any name), tiers menu with upgrade
  confirmation, paged history
- ☑ Every menu editable in `menus/*.yml`: layout, items, names, lore, sounds, actions, permissions,
  PlaceholderAPI placeholders
- ☑ Premium touches: gold theme, click/success/error sounds, the balance counts up or down after
  every change, fill, border and accent items
- ☑ Safe: every click cancelled, double clicks ignored, one operation at a time, menu items tagged
  and removed if they ever leave a menu, menus closed when the plugin stops
- ☑ Bedrock players through Geyser: chest menus and chat prompts both work
- ☑ Custom heads from minecraft-heads.com (Value, texture link or id) for any menu item or tier icon
- ☑ Alt-account limit: only the first N accounts per connection can use the bank (salted IP hashes,
  local addresses ignored, staff can allow accounts, `dkbank.alts.bypass`, `/bank admin alts`)

## Phase 5 · Integrations and admin tools — `0.5.0` ☑

- ☑ PlaceholderAPI `%dkbank_...%`: balance (full, short, raw), tier, rates, cap, room, next payout,
  rank, top N names and balances, server totals, alt lock. All from memory: safe for scoreboards and
  tab lists, from any thread
- ☑ `/bank top` leaderboard (chat and a podium menu), worked out every few minutes in the background,
  never per view; hidden accounts
- ☑ `/bank admin economy [days]`: money in banks, interest created per day and as a share of all bank
  money (inflation watch), deposits, withdrawals, transfers, upgrades, fees, top interest earners
- ☑ Number formatting: `short-from` shows big amounts short everywhere, `short-decimals` (0-2)
- ✗ Import from other bank plugins: decided against

## Phase 6 · Developer API — `0.6.0` ☑

- ☑ `DkBankAPI` service: accounts, cached balances, give, take, transfer, tiers (read, bought, set),
  alt lock, leaderboard, formatting. Futures complete on the main thread
- ☑ Events: `BankPreTransactionEvent` (deposit/withdraw/transfer, cancellable with a message),
  `BankTransactionEvent` (every balance change: deposits, interest, staff, plugins...),
  `BankUpgradeEvent` (cancellable), `BankTierChangeEvent`
- ☑ Javadocs and sources jars for `dkBank-API`, plus `api/README.md` (publishing to a public Maven
  repository is part of the release, Phase 8)
- ☑ Example addon in `example/`: a reward command, reading balances and tiers, blocking deposits in
  the nether, logging big transactions

## Phase 7 · Hardening (beta) — `0.9.0`

Done here (details in [TESTING.md](TESTING.md)):

- ☑ Crash test: killed 25 times mid-work, every cent accounted for
- ☑ Load test: 10,000 accounts; heartbeats batched into one transaction (200 players: 370 ms → 7 ms)
- ☑ Two full code reviews, all findings fixed:
  - a YAML mistake in config.yml no longer resets it to defaults (which could switch databases):
    dkBank refuses to start, and `/bank admin reload` keeps the old settings
  - MySQL upgrades are locked across servers and survive a crash half-way
  - a deposit or withdrawal whose save fails at the last moment is checked before refunding
  - refunds during shutdown run straight away instead of being dropped
  - maximum per payout scales with time, so relogging can't collect it repeatedly
  - switching servers on a network never pays the same minutes twice; a shortened period never
    pays twice
  - report sums can't overflow; placeholders never touch Bukkit or the economy plugin off-thread
  - cached accounts of players who left are cleaned up; duplicate logins keep their account
  - economy plugin errors are caught; bad menu slot ranges can't freeze the server
  - `/bank admin reload` re-checks the alt limit for players online
- ☑ Warnings for unknown settings (typos) in config.yml and tiers.yml
- ☑ Optional MySQL/MariaDB test suite (`MySqlStoreTest`)

On a real server (checklist in TESTING.md):

- ☐ Paper and Purpur **1.21.4, 1.21.11, 26.1, 26.3**, SQLite and MySQL
- ☐ Exploit tests in game, spark profile with players online
- ☐ Run on our own server for a while before selling

## Phase 8 · Release — `1.0.0` ☑

- ☑ Documentation in `docs/`: installation, interest, every setting, tiers, menus, commands and
  permissions, placeholders, alt-account limit, FAQ
- ☑ Store page text (`sales/description-bbcode.txt`, `sales/description.md`), screenshot list and release
  steps (`sales/RELEASE.md`)
- ☑ `/bank admin info` for support requests
- ☑ Update checker (switched on by the SpigotMC resource id) and optional bStats (switched on by the
  bStats id)
- ☐ Your part: screenshots, Discord, publishing the docs, the two ids, and the real-server checklist

---

## Later (after 1.0)

- Folia support
- Code obfuscation (Developer API left readable)
- Bedrock forms through Floodgate
- Multiple currencies (VaultUnlocked)
- Bank cheques, savings goals, team or island accounts, loans
- Investment shares (planned earlier, set aside for now)

## Open questions

1. Which bank plugins to support importing from (see Phase 5)
2. GUI theme or colors you'd like dkBank to be known for
